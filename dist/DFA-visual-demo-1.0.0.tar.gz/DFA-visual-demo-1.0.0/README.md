https://pypi.org/project/dfa-visual-demo/

Download : [here](https://github.com/spirosmaggioros/DFA_Visualization/releases/tag/v0.1)

Linux/MacOS
use :
1) Αρχικά Πρέπει να βρισκόμαστε στο directory που υπάρχει το executable file(cd Downloads για τους περισσότερους)
2) pip3 install automathon(ή brew install automathon για macos)
3) pip3 install graphviz(ή brew install graphviz για macos)
4) chmod +x dfa_create
5) ./dfa_create

Windows
use :
Double-Click το executable file

![εικόνα](https://user-images.githubusercontent.com/51701672/202444418-f0d25cbf-11a5-4502-b39b-9b41124e0ecf.png)
